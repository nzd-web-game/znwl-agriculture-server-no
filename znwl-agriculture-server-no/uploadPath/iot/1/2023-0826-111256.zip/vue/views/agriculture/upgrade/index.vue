<template>
  <div class="app-container-sm">
      <el-card class="card-margin-bottom">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px" class="form-minus-bottom">
      <el-form-item label="是否强制升级" prop="isForceUpdate">
        <el-input
          v-model="queryParams.isForceUpdate"
          placeholder="请输入是否强制升级"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="apk升级地址" prop="androidUrl">
        <el-input
          v-model="queryParams.androidUrl"
          placeholder="请输入apk升级地址"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="ios升级地址" prop="iosUrl">
        <el-input
          v-model="queryParams.iosUrl"
          placeholder="请输入ios升级地址"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="升级内容描述" prop="con">
        <el-input
          v-model="queryParams.con"
          placeholder="请输入升级内容描述"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="版本号" prop="version">
        <el-input
          v-model="queryParams.version"
          placeholder="请输入版本号"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="wgt版本号" prop="wgtVersion">
        <el-input
          v-model="queryParams.wgtVersion"
          placeholder="请输入wgt版本号"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="版本名称" prop="versionName">
        <el-input
          v-model="queryParams.versionName"
          placeholder="请输入版本名称"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="应用版本号" prop="versionCode">
        <el-input
          v-model="queryParams.versionCode"
          placeholder="请输入应用版本号"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="测试用户" prop="testUser">
        <el-input
          v-model="queryParams.testUser"
          placeholder="请输入测试用户"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="是否启用 0不启用 1启用" prop="isCurrent">
        <el-input
          v-model="queryParams.isCurrent"
          placeholder="请输入是否启用 0不启用 1启用"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="排序" prop="orderNum">
        <el-input
          v-model="queryParams.orderNum"
          placeholder="请输入排序"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
        <el-form-item class="fr">
            <el-button
                    type="primary"
                    plain
                    icon="el-icon-plus"
                    size="mini"
                    @click="handleAdd"
                    v-hasPermi="['agriculture:upgrade:add']"
            >新增</el-button>
            <el-button
                    type="warning"
                    plain
                    icon="el-icon-download"
                    size="mini"
                    @click="handleExport"
                    v-hasPermi="['agriculture:upgrade:export']"
            >导出</el-button>
        </el-form-item>
    </el-form>
      </el-card>
<el-card class="card-padding-bottom">
    <el-table v-loading="loading" :data="upgradeList" >
      <el-table-column label="升级类型" align="center" prop="updateType" />
      <el-table-column label="是否强制升级" align="center" prop="isForceUpdate" />
      <el-table-column label="apk升级地址" align="center" prop="androidUrl" />
      <el-table-column label="ios升级地址" align="center" prop="iosUrl" />
      <el-table-column label="升级内容描述" align="center" prop="con" />
      <el-table-column label="版本号" align="center" prop="version" />
      <el-table-column label="wgt版本号" align="center" prop="wgtVersion" />
      <el-table-column label="版本名称" align="center" prop="versionName" />
      <el-table-column label="应用版本号" align="center" prop="versionCode" />
      <el-table-column label="测试用户" align="center" prop="testUser" />
      <el-table-column label="是否启用 0不启用 1启用" align="center" prop="isCurrent" />
      <el-table-column label="备注" align="center" prop="remark" />
      <el-table-column label="状态 " align="center" prop="status" />
      <el-table-column label="排序" align="center" prop="orderNum" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['agriculture:upgrade:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['agriculture:upgrade:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
</el-card>
    <!-- 添加或修改App升级对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="是否强制升级" prop="isForceUpdate">
          <el-input v-model="form.isForceUpdate" placeholder="请输入是否强制升级" />
        </el-form-item>
        <el-form-item label="apk升级地址" prop="androidUrl">
          <el-input v-model="form.androidUrl" placeholder="请输入apk升级地址" />
        </el-form-item>
        <el-form-item label="ios升级地址" prop="iosUrl">
          <el-input v-model="form.iosUrl" placeholder="请输入ios升级地址" />
        </el-form-item>
        <el-form-item label="升级内容描述" prop="con">
          <el-input v-model="form.con" placeholder="请输入升级内容描述" />
        </el-form-item>
        <el-form-item label="版本号" prop="version">
          <el-input v-model="form.version" placeholder="请输入版本号" />
        </el-form-item>
        <el-form-item label="wgt版本号" prop="wgtVersion">
          <el-input v-model="form.wgtVersion" placeholder="请输入wgt版本号" />
        </el-form-item>
        <el-form-item label="版本名称" prop="versionName">
          <el-input v-model="form.versionName" placeholder="请输入版本名称" />
        </el-form-item>
        <el-form-item label="应用版本号" prop="versionCode">
          <el-input v-model="form.versionCode" placeholder="请输入应用版本号" />
        </el-form-item>
        <el-form-item label="测试用户" prop="testUser">
          <el-input v-model="form.testUser" placeholder="请输入测试用户" />
        </el-form-item>
        <el-form-item label="是否启用 0不启用 1启用" prop="isCurrent">
          <el-input v-model="form.isCurrent" placeholder="请输入是否启用 0不启用 1启用" />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
        </el-form-item>
        <el-form-item label="排序" prop="orderNum">
          <el-input v-model="form.orderNum" placeholder="请输入排序" />
        </el-form-item>
        <el-form-item label="删除标志" prop="delFlag">
          <el-input v-model="form.delFlag" placeholder="请输入删除标志" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listUpgrade, getUpgrade, delUpgrade, addUpgrade, updateUpgrade } from "@/api/agriculture/upgrade";

export default {
  name: "Upgrade",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // App升级表格数据
      upgradeList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        updateType: null,
        isForceUpdate: null,
        androidUrl: null,
        iosUrl: null,
        con: null,
        version: null,
        wgtVersion: null,
        versionName: null,
        versionCode: null,
        testUser: null,
        isCurrent: null,
        status: null,
        orderNum: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询App升级列表 */
    getList() {
      this.loading = true;
      listUpgrade(this.queryParams).then(response => {
        this.upgradeList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        recordId: null,
        updateType: null,
        isForceUpdate: null,
        androidUrl: null,
        iosUrl: null,
        con: null,
        version: null,
        wgtVersion: null,
        versionName: null,
        versionCode: null,
        testUser: null,
        isCurrent: null,
        remark: null,
        status: "0",
        orderNum: null,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        delFlag: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加App升级";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const recordId = row.recordId || this.ids
      getUpgrade(recordId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改App升级";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.recordId != null) {
            updateUpgrade(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addUpgrade(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const recordIds = row.recordId || this.ids;
      this.$modal.confirm('是否确认删除App升级编号为"' + recordIds + '"的数据项？').then(function() {
        return delUpgrade(recordIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('agriculture/upgrade/export', {
        ...this.queryParams
      }, `upgrade_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
