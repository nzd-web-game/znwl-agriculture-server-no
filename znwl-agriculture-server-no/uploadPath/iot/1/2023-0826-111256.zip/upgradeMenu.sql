-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('App升级', '1', '1', 'upgrade', 'agriculture/upgrade/index', 1, 0, 'C', '0', '0', 'agriculture:upgrade:list', '#', 'admin', sysdate(), '', null, 'App升级菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('App升级查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'agriculture:upgrade:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('App升级新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'agriculture:upgrade:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('App升级修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'agriculture:upgrade:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('App升级删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'agriculture:upgrade:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('App升级导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'agriculture:upgrade:export',       '#', 'admin', sysdate(), '', null, '');